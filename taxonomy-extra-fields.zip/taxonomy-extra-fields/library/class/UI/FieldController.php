<?php

namespace tef\UI;

defined( 'ABSPATH' ) or die('Don\'t touch the eggs, please!');

use \tef\Auxiliary\TaxonomyFieldsTable;

/**
 * 
 * @author GuilleGarcia
 *
 */
class FieldController{
	
	/**
	 * 
	 */
	function listAction(){
		
	}
	
	/**
	 * Create a new Field
	 */
	function createAction(){
		
	}
	
	/**
	 * View a field
	 */
	function readAction(){
		
	}
	
	/**
	 * 
	 * Edit a Field
	 */
	function editAction(){
		
		
	}
	
	/**
	 * Delete a Field
	 */
	function deleteAction(){
		
	}
}